
Hard_Configurator Disclaimer of Warranty
THIS SOFTWARE IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND IS EXPRESSED OR IMPLIED. YOU USE IT AT YOUR OWN RISK. THE AUTHOR WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING  THIS SOFTWARE.

Distribution
Hard_Configurator may be freely distributed as long as no modification is made to it. Hard_Configurator can use as external software Sysinternals Autoruns, NirSoft FullEventLogView, and command line 7-ZIP, which have their own Software License Terms .

I would like to thank the members of https://www.autoitscript.com/forum/ , especially: Ascend4nt, Erik Pilsits, FredAI, Melba23, trancexx, Valuater, and many others, for sharing their insightful code.

Andy Ful